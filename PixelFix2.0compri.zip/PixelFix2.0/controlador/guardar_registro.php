<!DOCTYPE html>
<html lang="es">
<link rel="stylesheet" href="../vistas/CSS/estilos.css">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Proyecto</title>
</head>
<body>
    <header>
      <?php

           include "../vistas/vista_encabesado.php";

      ?>
    </header>
    <nav class="main-menu">
     <?php

         include "../vistas/vista_menusuperior.php"

      ?>
    </nav>
    
    <div class="content">
        <nav class="sub-menu">
         <?php

              include "../vistas/vista_menuinterno.php"

         ?>
        </nav>
        <h2>USUARIO REGISTRADO</h2>
        <p> Gracias :).</p>";
        <?php
$archivo_usuarios = "../modelo/Dataso.txt";

// Carpeta de destino para las imágenes
$carpeta_imagenes = $_SERVER['DOCUMENT_ROOT'] . '/P2-V3/Imagenes_registradas/';


// Verificar si la carpeta de imágenes existe
if (!is_dir($carpeta_imagenes)) {
    mkdir($carpeta_imagenes, 0777, true); // Crear carpeta si no existe
}

// Validar entrada y establecer valores predeterminados
$nombre = isset($_POST["Nombre"]) ? htmlspecialchars(trim($_POST["Nombre"])) : "No especificado";
$correo = isset($_POST["Correo"]) ? htmlspecialchars(trim($_POST["Correo"])) : "No especificado";
$mensaje = isset($_POST["mensaje"]) ? htmlspecialchars(trim($_POST["mensaje"])) : "No especificado";
$fecha = isset($_POST["fecha"]) ? htmlspecialchars(trim($_POST["fecha"])) : "No especificada";
$imagen = isset($_FILES['imagen']) ? $_FILES['imagen'] : null;

// Validar contraseñas
$passw = isset($_POST['password']) ? trim($_POST['password']) : null;
$confirm_passw = isset($_POST['confirmpassword']) ? trim($_POST['confirmpassword']) : null;

if (!$passw || !$confirm_passw) {
    echo "<p style='color: red;'>Las contraseña es awebo >:(.</p>";
} elseif ($passw !== $confirm_passw) {
    echo "<p style='color: red;'>Las contraseñas no coinciden :(.</p>";
} else {
    // Leer el archivo de usuarios registrados
    if (file_exists($archivo_usuarios)) {
        $usuarios_registrados = file($archivo_usuarios, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    } else {
        $usuarios_registrados = [];
    }

    // Validar si el correo ya existe en el archivo
    $correo_existente = false;
    foreach ($usuarios_registrados as $linea) {
        $datos = explode('|', $linea);
        if (isset($datos[1]) && $datos[1] === $correo) { // El correo está en la posición 1
            $correo_existente = true;
            break;
        }
    }

    if ($correo_existente) {
        echo "<p style='color: red;'>El usuario con el correo '$correo' ya está registrado.</p>";
    } else {
        // Cifrar la contraseña
        $passw_cifrada = password_hash($passw, PASSWORD_DEFAULT);
        $cifusr = md5($correo);

        // Procesar la imagen
        if ($imagen && $imagen['error'] === 0) {
            $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'avif', 'jfif'];
            $nombreArchivo = basename($imagen['name']);
            $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));

            if (in_array($extension, $extensiones_permitidas)) {
                $nombre_unico = uniqid('img_') . '.' . $extension;
                $rutaDestino = $carpeta_imagenes . $nombre_unico;

                if (move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {
                    // Preparar la línea de datos para guardar
                    $linea_datos = "$nombre|$correo|$passw_cifrada|$fecha|$mensaje|$nombre_unico\n";

                    // Guardar en el archivo
                    if (file_put_contents($archivo_usuarios, $linea_datos, FILE_APPEND | LOCK_EX)) {
                        // Mostrar datos ingresados
                        echo "<p><b>El nombre es:</b> $nombre</p>";
                        echo "<p><b>El correo cifrado es:</b> $cifusr</p>";
                        echo "<p><b>El mensaje es:</b> $mensaje</p>";
                        echo "<p><b>Fecha de Nacimiento:</b> $fecha</p>";
                        echo "<p><b>Contraseña (cifrada):</b> $passw_cifrada</p>";
                        echo "<p><b>Imagen subida:</b></p>";
                        echo "<p><img src='/frameworksp3_v4/uploads/$nombre_unico' alt='Imagen subida' width='150'></p>";
                        echo "<p style='color: green;'>Usuario registrado con éxito y datos guardados.</p>";
                    } else {
                        echo "<p style='color: red;'>Error al guardar los datos en el archivo.</p>";
                    }
                } else {
                    echo "<p style='color: red;'>Error al subir la imagen :(.</p>";
                }
            } else {
                echo "<p style='color: red;'>El formato de la imagen no es válido estup... Solo se permiten JPG, JPEG, PNG y GIF.</p>";
            }
        } else {
            echo "<p style='color: red;'>Debe seleccionar una imagen válida pend...</p>";
        }
    }
}   
        ?>
    </div>
     <?php

         include "../vistas/vista_piedepagina.php"

     ?>
    
         <link rel="stylesheet" href="../vistas/CSS/estilo_redes.css">
<div class="social-bar">
    <a href="https://facebook.com" target="_blank" class="social-icon facebook">Facebook</a>
    <a href="https://x.com/elzombirren" target="_blank" class="social-icon twitter">Twitter</a>
    <a href="https://wa.me/<4925441644>" target="_blank" class="social-icon WhatsApp">WhatsApp</a>
    <a href="https://www.Youtube.com/@zombirren" target="_blank" class="social-icon youtube">youtube</a>
</div>
        
    
</body>
</html>
