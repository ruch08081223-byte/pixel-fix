<!DOCTYPE html>
<html lang="es">
<link rel="stylesheet" href="../vistas/CSS/estilos.css">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Proyecto</title>
</head>
<body>
    <header>
      <?php

           include "../vistas/vista_encabesado.php";

      ?>
    </header>
    <nav class="main-menu">
     <?php

         include "../vistas/vista_menusuperior.php"

      ?>
    </nav>
    
    <div class="content">
        <nav class="sub-menu">
         <?php

              include "../vistas/vista_menuinterno.php"

         ?>
        </nav>
        <h2>FORMULARIO COMPLETO</h2>
        <p>Te responderemos pronto.</p>";
        <?php
        
        $nombre=$_POST["nombre"];

        $correo=$_POST["correo"];

        $mensaje=$_POST["mensaje"];


        echo "<p>El nombre es: <b>".$nombre."</b></p>";

        echo "<p>El correo es: <b>".$correo."</b></p>";

        echo "<p>El mensaje es: <b>".$mensaje."</b></p>";

              
        ?>
    </div>
     <?php

         include "../vistas/vista_piedepagina.php"

     ?>
    
         <link rel="stylesheet" href="../vistas/CSS/estilos_redes.css">
<div class="social-bar">
    <a href="https://facebook.com" target="_blank" class="social-icon facebook">Facebook</a>
    <a href="https://x.com/elzombirren" target="_blank" class="social-icon twitter">Twitter</a>
    <a href="https://wa.me/<4925441644>" target="_blank" class="social-icon WhatsApp">WhatsApp</a>
    <a href="https://www.Youtube.com/@zombirren" target="_blank" class="social-icon youtube">Youtube</a>
</div>
        
    
</body>
</html>
