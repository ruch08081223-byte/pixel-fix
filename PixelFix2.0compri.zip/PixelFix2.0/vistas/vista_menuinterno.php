<link rel="stylesheet" href="../vistas/CSS/estilos.css">
</head>
<body>
  <div class="container">
    <aside class="sidebar" id="sidebar" aria-label="Menú de navegación">
      <div class="brand">
        <div class="logo">MI</div>
        <div>
          <h1>Menú Interno</h1>
          <div class="muted">Navegación rápida</div>
        </div>
      </div>

      <div style="padding:8px 6px">
        <button class="mobile-toggle" id="toggleButton" aria-expanded="true">☰ Abrir/ocultar menú</button>
      </div>


      <div style="padding:10px 6px;border-top:1px solid rgba(255,255,255,0.02);margin-top:8px">
        <div class="muted">Atajos</div>
        <div style="display:flex;gap:8px;margin-top:8px">
          <div class="kbd">1</div><div class="muted">Ir a Inicio</div>
        </div>
        <div style="display:flex;gap:8px;margin-top:6px">
          <div class="kbd">2</div><div class="muted">Ir a Acerca</div>
        </div>
      </div>
    </aside>

    <main class="content" id="mainContent">
      <section id="inicio">
        <h2>Inicio</h2>
        <p>Bienvenido al menú de PixelFix Donde podras encontrar lo basico sobre nosotros.</p>
      </section>

      <section id="acerca">
        <h2>Acerca</h2>
        <p>Somos una empresa de Reparacion y mantenimiento de dispocitivos electronicos con especialidad en computadoras y consolas.</p>
      </section>

      <section id="rec1">
        <h2>Fundadores</h2>
        <p>Hector Santiago Ruiz Cano:Encargado de software,harware y programacion, Gadiel Izai Martines Torres:Encargado de electronica y circuiteria, Luis Angel Valenzuela Sosa:Encargado de Diseño y Limpieza de dispositivos.</p>
      </section>

      <section id="rec2">
        <h2>Tipos de Servicios</h2>
        <p>Ofrecemos una buena cantidad de servicios como Reparacion de cualquier dispositivo electronico, Mantenimiento y limpienza de dispositivos, Restauraion de ser posible, y venta de videojuegos.</p>
      </section>

      <section id="rec3">
        <h2>Recurso 3</h2>
        <p>Contenido del recurso 3.</p>
      </section>

      <section id="contacto">
        <h2>Contacto</h2>
        <p>Información de contacto o formulario de ejemplo.</p>
      </section>

    </main>

    <div class="overlay" id="overlay"></div>
  </div>

  <script>
    // Smooth scroll for internal links
    document.querySelectorAll('a.menu-link[href^="#"]').forEach(a=>{
      a.addEventListener('click', (e)=>{
        const target = a.getAttribute('href').slice(1);
        if(!target) return; // if it's just '#'
        e.preventDefault();
        const el = document.getElementById(target);
        if(el){
          el.scrollIntoView({behavior:'smooth',block:'start'});
          // update active classes
          document.querySelectorAll('.menu-link').forEach(x=>x.classList.remove('active'));
          a.classList.add('active');
        }
      })
    })

    // Submenu toggle
    document.querySelectorAll('.submenu-toggle').forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        e.preventDefault();
        const id = btn.dataset.target;
        const sub = document.getElementById(id);
        if(sub){
          sub.classList.toggle('open');
        }
      })
    })

    // Keyboard shortcuts (1 => inicio, 2 => acerca)
    window.addEventListener('keydown', (e)=>{
      if(e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if(e.key === '1') document.querySelector('a[href="#inicio"]').click();
      if(e.key === '2') document.querySelector('a[href="#acerca"]').click();
    });

    // Mobile toggle behavior
    const toggleBtn = document.getElementById('toggleButton');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    if(toggleBtn){
      toggleBtn.addEventListener('click', ()=>{
        const isHidden = sidebar.style.transform === 'translateY(-10px)';
        if(window.innerWidth <= 900){
          // simple show/hide by toggling overlay
          overlay.classList.toggle('show');
          sidebar.style.transform = overlay.classList.contains('show') ? 'translateY(0)' : 'translateY(-10px)';
        }
      });
      overlay.addEventListener('click', ()=>{ overlay.classList.remove('show'); sidebar.style.transform='translateY(-10px)'; });
    }

    // Highlight menu item on scroll
    const sectionEls = Array.from(document.querySelectorAll('main section[id]'));
    window.addEventListener('scroll', ()=>{
      const mid = window.scrollY + window.innerHeight/3;
      let currentId = '';
      for(const s of sectionEls){
        if(s.offsetTop <= mid) currentId = s.id;
      }
      if(currentId){
        document.querySelectorAll('.menu-link').forEach(x=>x.classList.remove('active'));
        const link = document.querySelector('.menu-link[href="#'+currentId+'"]');
        if(link) link.classList.add('active');
      }
    });
  </script>
</body>
</html>

</html>