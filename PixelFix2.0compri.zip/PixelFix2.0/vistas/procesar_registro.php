<?php
// Conexion a la base de datos
$conexion = new mwsql("localhost", "root", "", "cientesyencargos");

// verificamos conexion
if ($conexion->connect_error) {
	die("Error de conexion: " .
$conexion->connect_error);
}

// Recibimos los datos del formulario
$Nombres = $_POST['Nombres'];
$apellidos = $_POST['Apellidos'];
$Numerodecontacto = $_POST['Telefono'];
$Fechadepedido = $_POST['Fechapedido'];
$Edad = $_POST['Edad'];
$Direccion = $_POST['Direccion'];

// Insertamos en la tabla
$sql = "INSERT INTO clientes (Nombres, Apellidos, Telefono, Fechapedido, Edad, Direccion) VALUES ('$Nombres', '$apellidos', '$Numerodecontacto', '$Fechadepepido', '$Edad', '$Direccion')";

if ($conexion->query($sql) === TRUE) {
	echo "Usuario registrado con exito.";
	echo "<br><a href='vista_registro.php'>Registrar otro</a>";
} else {
	echo "Error: " . $conexion->error;
}

$conexion->close();
?>