

    <aside class="sidebar" id="sidebar" aria-label="Menú de navegación">
      <div class="brand">
        <div class="logo">MI</div>
        <div>
          <h1>Menú Interno</h1>
          <div class="muted">Navegación rápida</div>
        </div>
      </div>

      <div style="padding:8px 6px">
        <button class="mobile-toggle" id="toggleButton" aria-expanded="true">☰ Abrir/ocultar menú</button>
      </div>
    
    </aside>

<link rel="stylesheet" href="../vistas/CSS/estilos.css">

<script src="../vistas/JC/contraseñas.js"></script>

<script src="../vistas/JC/archivos_imagenes.js"></script>

<script src="../vistas/JC/encriptado.js"></script>

    </aside>
<main class="content" id="mainContent">

<h1>Registro</h1>
<form id="Formulario" action="../controlador/guardar_registro.php" method="post" enctype="multipart/form-data">
    <div>
        <p>
            <label>Nombre completo:</label>
            <input type="text" name="Nombre" required>
        </p>

        <p>
            <label>Numero Telefónico:</label>
            <input type="tel" name="cel" required>
        </p>

        <p>
            <label>Correo Electrónico:</label>
            <input type="email" name="Correo" required>
        </p>

        <p>
            <label>Contraseña:</label>
            <input type="password" id="password" name="password" required>
        </p>

        <p>
            <label>Confirmar Contraseña:</label>
            <input type="password" id="confirmpassword" name="confirmpassword" required>
        </p>

        <p>
            <label>Fecha de Nacimiento:</label>
            <input type="date" name="fecha" required>
        </p>

        <p>
            <label for="imagen">Selecciona una imagen:</label>
            <input type="file" id="imagen" name="imagen" accept="image/*">
        </p>

        <p>
            <label>Mensaje:</label>
            <textarea name="mensaje" rows="4" required></textarea>
        </p>

        <p>
            <button type="submit">
                <img src="../vistas/imagen/archivo.png" alt="Enviar Registro">
            </button>
        </p>

        <!-- Mensajes de error -->
        <p id="errorpsw" style="color: red; display: none;">Las contraseñas no coinciden</p>
        <p id="file-error" style="color: red; display: none;">Solo puedes subir archivos de imagen</p>
    </div>
</form>
    </main>
