<link rel="stylesheet" href="../vistas/CSS/estilos.css">
<marquee>  <h1>PIXEL FIX.</h1></marquee>
        <img src="../vistas/imagen/logo pixelfix.jpg"> 