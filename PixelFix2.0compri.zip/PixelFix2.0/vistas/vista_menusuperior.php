<link rel="stylesheet" href="../vistas/CSS/Estilos.css">

<ul>
    <li><a href="../public/html2.intex.php">Inicio</a></li>
    <li><a href="../public/reguistro.php">Registro</a></li>
    <li><a href="../public/acerca_de.php">Sobre Nosotros</a></li>
    <li><a href="../public/contactos.php">Inicio de secion</a></li>
</ul>
