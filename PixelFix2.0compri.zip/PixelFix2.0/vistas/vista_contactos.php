 <h1>Inicio de Secion</h1>

    <section class="contact-info"> 
        <h2>Formulario de inicio de secion</h2>
    </section>

    <section class="contact-form">
        <h2>SECION</h2>
        <form action="../controlador/guardar_mensaje.php" method="post">

            <link rel="stylesheet" href="../vistas/CSS/estiloscontacto.css">



            <label for="nombre">Usuario:</label>
            <input type="text" id="nombre" name="nombre" required>



            <label for="correo">Correo electrónico:</label>
            <input type="email" id="correo" name="correo" required>




            <label for="mensaje">contraseña:</label>
            <input type="mensaje" name="mensaje" required>




            <button type="submit">Iniciar</button>
        </form>


