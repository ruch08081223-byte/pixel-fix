document.addEventListener("DOMContentLoaded", function () {
        // Asociar el evento al formulario
        const formulario = document.getElementById("Formulario");
        if (formulario) {
            formulario.addEventListener("submit", function (e) {
                validarImagen(e);
            });
        } else {
            console.error("Formulario no encontrado");
        }
    });

    function validarImagen(e) {
        // Obtener el input del archivo
        const fileInput = document.getElementById("imagen");
        const errorElement = document.getElementById("file-error");

        // Asegurarse de que el elemento exista
        if (!fileInput) {
            console.error("Campo de imagen no encontrado");
            return;
        }

        const file = fileInput.files[0]; // Obtener el archivo seleccionado

        // Validar si no se seleccionó un archivo
        if (!file) {
            e.preventDefault(); // Detener el envío del formulario
            mostrarError("Por favor, selecciona un archivo de imagen.");
            return;
        }

        // Validar si el tipo de archivo es válido
        const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
        if (!validTypes.includes(file.type)) {
            e.preventDefault(); // Detener el envío del formulario
            mostrarError("El archivo seleccionado no es una imagen válida.");
            return;
        }

        // Validar tamaño máximo del archivo (opcional)
        const maxSize = 5 * 1024 * 1024; // 5 MB
        if (file.size > maxSize) {
            e.preventDefault(); // Detener el envío del formulario
            mostrarError("El tamaño del archivo debe ser menor a 5 MB.");
            return;
        }

        // Si todo está bien, ocultar mensaje de error
        ocultarError();
    }

    function mostrarError(mensaje) {
        const errorElement = document.getElementById("file-error");
        if (errorElement) {
            errorElement.textContent = mensaje;
            errorElement.style.display = "block";
        }
    }

    function ocultarError() {
        const errorElement = document.getElementById("file-error");
        if (errorElement) {
            errorElement.style.display = "none";
        }
    }