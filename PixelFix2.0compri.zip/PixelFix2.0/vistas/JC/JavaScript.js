// Obtener el formulario y el enlace para descargar el archivo
    const form = document.getElementById('dataForm');
    const downloadLink = document.getElementById('downloadLink');

    form.addEventListener('submit', function(event) {
      event.preventDefault();  // Evitar el envío del formulario

      // Obtener los valores del formulario
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const date = document.getElementById('date').value;

      // Crear el contenido del archivo de texto
      const fileContent = `Nombre: ${name}\nCorreo: ${email}\nFecha: ${date}\n`;

      // Crear un Blob con el contenido del archivo
      const blob = new Blob([fileContent], { type: 'text/plain' });

      // Crear una URL para el archivo Blob
      const fileUrl = URL.createObjectURL(blob);

      // Establecer el enlace de descarga
      downloadLink.href = fileUrl;
      downloadLink.download = 'datos_usuario.txt';  // Nombre del archivo
      downloadLink.style.display = 'inline';  // Mostrar el enlace de descarga
      downloadLink.textContent = 'Descargar archivo con tus datos';
    });
