async function generarClaveAES() {
    const key = await crypto.subtle.generateKey(
        {
            name: "AES-GCM",
            length: 256, // Tamaño de la clave (256 bits)
        },
        true, // La clave puede ser exportada
        ["encrypt", "decrypt"] // Permitir operaciones de cifrado y descifrado
    );
    return key;
}

// Función para cifrar la contraseña
async function cifrarContraseña(password, key) {
    const encoder = new TextEncoder();
    const passwordData = encoder.encode(password); // Convertir la contraseña en un ArrayBuffer

    const iv = crypto.getRandomValues(new Uint8Array(12)); // Vector de inicialización aleatorio (12 bytes para AES-GCM)

    // Cifrar la contraseña utilizando AES-GCM
    const encryptedData = await crypto.subtle.encrypt(
        {
            name: "AES-GCM",
            iv: iv, // Vector de inicialización
        },
        key, // Clave AES generada
        passwordData // Datos a cifrar (la contraseña)
    );

    // Convertir el resultado cifrado a un ArrayBuffer
    return { encryptedData, iv };
}

// Función para validar las contraseñas
function validarContraseñas(e) {
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmpassword").value.trim();

    const errorElement = document.getElementById("errorpsw");

    if (password !== confirmPassword) {
        e.preventDefault(); // Evitar que el formulario se envíe
        errorElement.style.display = "block"; // Mostrar el mensaje de error
    } else if (password === "" || confirmPassword === "") {
        e.preventDefault(); // Evitar que el formulario se envíe si las contraseñas están vacías
        errorElement.textContent = "Los campos de contraseña no pueden estar vacíos.";
        errorElement.style.display = "block";
    } else {
        errorElement.style.display = "none"; // Ocultar el mensaje de error
    }
}

// Función que se ejecuta al enviar el formulario
async function manejarFormulario(e) {
    // Validar las contraseñas primero
    validarContraseñas(e);

    if (e.defaultPrevented) return; // Si las contraseñas no coinciden, no enviamos el formulario

    // Si las contraseñas son válidas, ciframos la contraseña
    const password = document.getElementById("password").value;
    const key = await generarClaveAES(); // Generamos una nueva clave AES

    // Cifrar la contraseña
    const { encryptedData, iv } = await cifrarContraseña(password, key);

    // Convertir el ArrayBuffer cifrado a una cadena base64 para enviarlo
    const encryptedBase64 = arrayBufferToBase64(encryptedData);
    const ivBase64 = arrayBufferToBase64(iv);

    // Crear un campo oculto para enviar los datos cifrados
    const encryptedPasswordInput = document.createElement("input");
    encryptedPasswordInput.type = "hidden";
    encryptedPasswordInput.name = "encryptedPassword";
    encryptedPasswordInput.value = encryptedBase64;
    document.getElementById("Formulario").appendChild(encryptedPasswordInput);

    const ivInput = document.createElement("input");
    ivInput.type = "hidden";
    ivInput.name = "iv";
    ivInput.value = ivBase64;
    document.getElementById("Formulario").appendChild(ivInput);
}

// Convertir un ArrayBuffer a base64
function arrayBufferToBase64(buffer) {
    const byteArray = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < byteArray.byteLength; i++) {
        binary += String.fromCharCode(byteArray[i]);
    }
    return window.btoa(binary);
}

// Asociar el evento al formulario para cifrar la contraseña antes de enviarlo
document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("Formulario");
    if (formulario) {
        formulario.addEventListener("submit", manejarFormulario);
    } else {
        console.error("Formulario no encontrado.");
    }
});
