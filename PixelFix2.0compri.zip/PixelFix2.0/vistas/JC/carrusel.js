 let currentIndex = 0;
        const totalImages = 5; // Total de imágenes

        function showImage(index) {
            const images = document.querySelector(".carousel-images");
            images.style.transform = `translateX(-${index * 100}%)`; // Desplazar las imágenes
        }

        function prevImage() {
            currentIndex = (currentIndex === 0 ? totalImages - 1 : currentIndex - 1; // Retroceder
            showImage(currentIndex);
        }

        function nextImage() {
            currentIndex = (currentIndex === totalImages - 1) ? 0 : currentIndex + 1; // Avanzar
            showImage(currentIndex);
        }
