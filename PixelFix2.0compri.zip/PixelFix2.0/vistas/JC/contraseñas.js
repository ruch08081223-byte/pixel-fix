document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("Formulario");
    if (formulario) {
        formulario.addEventListener("submit", validarContraseñas);
    } else {
        console.error("Formulario no encontrado.");
    }
});

function validarContraseñas(e) {
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmpassword").value.trim();

    console.log("Password:", password);
    console.log("Confirm Password:", confirmPassword);

    if (password !== confirmPassword) {
        e.preventDefault();
        mostrarError("Las contraseñas no coinciden estup...");
    } else if (password === "" || confirmPassword === "") {
        e.preventDefault();
        mostrarError("La contraseña es awebo >:(.");
    } else {
        ocultarError();
    }
}

function mostrarError(mensaje) {
    const errorElement = document.getElementById("errorpsw");
    if (errorElement) {
        errorElement.textContent = mensaje;
        errorElement.style.display = "block";
    }
}

function ocultarError() {
    const errorElement = document.getElementById("errorpsw");
    if (errorElement) {
        errorElement.style.display = "none";
    }
}
