<!DOCTYPE html>
<html lang="es">
<link rel="stylesheet" href="../vistas/CSS/estilos.css">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Proyecto</title>
</head>
<body>
    <header>
      <?php

           include "../vistas/vista_encabesado.php";

      ?>
    </header>
    <nav class="main-menu">
     <?php

         include "../vistas/vista_menusuperior.php"

      ?>
    </nav>
  
        <h2>REGISTRO DE USUARIO</h2>
        <p> registrese por favor.</p>
        <?php

              include "../vistas/vista_reguistro.php"
              
        ?>
    </div>
     <?php

         include "../vistas/vista_piedepagina.php"

     ?>
    
  <footer>
     <link rel="stylesheet" href="../vistas/CSS/estilos_redes.css">
    <div class="footer-content">
  <div class="social-icons">
    <a href="https://www.facebook.com/TuPerfil" target="_blank">
      <img src="../vistas/imagen/Facebook.jpg" alt="Facebook">
    </a>
    <a href="https://www.twitter.com/TuPerfil" target="_blank">
      <img src="../vistas/imagen/Twitter.png" alt="Twitter">
    </a>
    <a href="https://www.instagram.com/TuPerfil" target="_blank">
      <img src="../vistas/imagen/Instagram.jpg" alt="Instagram">
    </a>
        <a href="https://www.Whatsapp.com/TuPerfil" target="_blank">
      <img src="../vistas/imagen/Whatsapp.png" alt="Whatsapp">
    </a>
        </a>
        <a href="https://www.Tiktok.com/TuPerfil" target="_blank">
      <img src="../vistas/imagen/Tiktok.png" alt="tiktok">
    </a>
    <!-- Puedes agregar más redes sociales aquí -->
  </div>
    </div>

</body>
</html>
